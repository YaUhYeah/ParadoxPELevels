package com.paradox.kitpvplevels;


import com.paradox.kitpvplevels.handlers.LevelHandler;

import cn.nukkit.Player;
import cn.nukkit.command.Command;
import cn.nukkit.command.CommandSender;

public class levelCmd extends Command {

	public levelCmd() {
		super("level", "check your current pvp level!", "/level");
		// TODO Auto-generated constructor stub
	}

	@Override
	public boolean execute(CommandSender sender, String label, String[] args) {
		Player p = (Player) sender;
		if (sender instanceof Player) {
			int level = Loader.playersCfg.getInt(p.getName()+".level");
			p.sendMessage("�b�l(�d�lLevelSystem�b�l)�r�7 Current: " + level);
			int selfXp = Loader.playersCfg.getInt(p.getName()+".exp");
			p.sendMessage("�b�l(�d�lLevelSystem�b�l)�r�7 Kills needed for levelup: " + (LevelHandler.checkLevelUp(p)-selfXp));
		}
		return false;
	}

}
