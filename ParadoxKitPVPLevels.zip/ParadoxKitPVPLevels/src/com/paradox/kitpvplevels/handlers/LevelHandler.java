package com.paradox.kitpvplevels.handlers;

import com.paradox.kitpvplevels.Loader;
import com.paradox.kitpvplevels.utils.StringUtils;

import cn.nukkit.Player;

public class LevelHandler {
	
	public static double checkLevelUp(Player p) {
		int level = Loader.playersCfg.getInt(p.getName()+".level");
		double exp = 1.75;
		int baseXP = 5;
		return Math.floor(baseXP * (Math.pow(level, exp)));
	}

	public static void addXp(int xp, Player p) {
		int selfXp = Loader.playersCfg.getInt(p.getName()+".exp");
		selfXp+=xp;
		Loader.playersCfg.set(p.getName()+".exp",selfXp);	
		Loader.playersCfg.save();
	}
	
	public static boolean readyToLevelup(int xp,Player p) {
		if (xp >= checkLevelUp(p)) {
			return true;
		}
		return false;
	}
	public static void setLevelup(Player p) {
		int level = Loader.playersCfg.getInt(p.getName()+".level");
		p.sendActionBar("�b�l(�d�l!�b�l)�r�b Levelled up!");
		Loader.playersCfg.set(p.getName()+".level",level+1);
		Loader.playersCfg.save();
	}
	
	public static String NextLvlString(Player p) {
		int selfXp = Loader.playersCfg.getInt(p.getName()+".exp");
		return "�b�l(�d�l!�b�l)�r�7 Level Progress: " + StringUtils.generatePercentageBar('|', checkLevelUp(p)-selfXp, checkLevelUp(p), "�b", "�7");
	}
	
}
