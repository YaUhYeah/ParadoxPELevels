package com.paradox.kitpvplevels.handlers;
import com.paradox.kitpvplevels.Loader;
import cn.nukkit.Player;
import me.onebone.economyapi.EconomyAPI;

public class KillHandler {
	
	public static void addKill(Player p) {
		EconomyAPI.getInstance().addMoney(p, 5);
		p.sendMessage("�b�l(�d�l!�b�l)�r�b Got $5 for killing a player!");
		Loader.playersCfg.set(p.getName()+".kills", Loader.playersCfg.getInt(p.getName()+".kills") + 1);
		Loader.playersCfg.set(p.getName()+".exp", Loader.playersCfg.getInt(p.getName()+".exp") + 1);
		Loader.playersCfg.save();
		if (LevelHandler.readyToLevelup(Loader.playersCfg.getInt(p.getName()+".exp") , p)) {
			LevelHandler.setLevelup(p);
		}
	}
}
