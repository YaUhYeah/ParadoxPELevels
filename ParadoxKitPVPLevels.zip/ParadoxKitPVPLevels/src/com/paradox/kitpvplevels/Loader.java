package com.paradox.kitpvplevels;

import java.io.File;
import com.paradox.kitpvplevels.listeners.ListenerPvp;

import cn.nukkit.plugin.PluginBase;
import cn.nukkit.utils.Config;

public class Loader extends PluginBase {
	private static Loader loader;
	public static Loader getInstance() {
		return loader;
	}
	@Override 
	public void onLoad() {
		loader = this;
	}
	public static Config playersCfg;
	@Override
	public void onEnable() {
		getDataFolder().mkdirs();
		getConfig().save();
		saveResource("players.yml");
		getServer().getCommandMap().register("level",new levelCmd());
		playersCfg = new Config(new File(getDataFolder(), "players.yml"));
		getServer().getPluginManager().registerEvents(new ListenerPvp(), this);
	}
		
}
