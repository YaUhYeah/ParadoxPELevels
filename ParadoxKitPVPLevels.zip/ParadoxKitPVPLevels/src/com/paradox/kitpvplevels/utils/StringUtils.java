package com.paradox.kitpvplevels.utils;

public class StringUtils {
		  public static String generatePercentageBar(char barChar, double current, double maximum, String complete, String incomplete)
		  {
		    String bar = "";
		    if (maximum == 0.0D) {
		      maximum = current;
		    }
		    double percentage = current / maximum * 100.0D;
		    long percentageRounded = Math.round(percentage) / 2L;
		    for (int i = 0; i < 50; i++)
		    {
		      bar = bar + (percentageRounded > 0L ? complete : incomplete) + barChar;
		      if (percentageRounded > 0L) {
		        percentageRounded -= 1L;
		      }
		    }
		    return bar;
		  }
}
