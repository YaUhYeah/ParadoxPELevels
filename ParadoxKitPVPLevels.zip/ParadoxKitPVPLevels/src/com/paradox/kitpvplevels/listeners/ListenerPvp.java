package com.paradox.kitpvplevels.listeners;

import com.paradox.kitpvplevels.Loader;
import com.paradox.kitpvplevels.handlers.KillHandler;
import com.paradox.kitpvplevels.handlers.LevelHandler;

import cn.nukkit.Player;
import cn.nukkit.event.EventHandler;
import cn.nukkit.event.EventPriority;
import cn.nukkit.event.Listener;
import cn.nukkit.event.player.PlayerChatEvent;
import cn.nukkit.event.player.PlayerDeathEvent;
import cn.nukkit.event.player.PlayerJoinEvent;

public class ListenerPvp implements Listener {
	
	@EventHandler
	public void onKill(PlayerDeathEvent e) {
		Player p = (Player) e.getEntity().getKiller();
		if (p instanceof Player) {
			p.sendActionBar(LevelHandler.NextLvlString(p));
			KillHandler.addKill(p);
		}
	}
	
	@EventHandler(priority = EventPriority.HIGHEST)
	public void onJoin(PlayerJoinEvent e) {
		Player p = (Player) e.getPlayer();
		if (!p.hasPlayedBefore() || Loader.playersCfg.getInt(p.getName())==0) {
			Loader.playersCfg.set((p.getName() + ".level"), 1);
			Loader.playersCfg.save();
		}
	}
	
	@EventHandler(priority = EventPriority.HIGHEST)
	public void onChat(PlayerChatEvent e) {
		Player p = e.getPlayer();
		int level = Loader.playersCfg.getInt(p.getName()+".level");
		e.setFormat("�8[�7"+level+"�8] " +e.getFormat());
	}

}
